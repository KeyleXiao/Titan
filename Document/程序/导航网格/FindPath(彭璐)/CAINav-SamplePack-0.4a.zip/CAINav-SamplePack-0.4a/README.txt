Sample Pack Version: 0.4a

This distribution contains various demos related to CAINav.

CritterAI Home: http://www.critterai.org/
CritterAI Code: http://code.google.com/p/critterai/ 

SamplePack <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

Includes a combiled executable along with the source 
Unity project. It includes the following:

Crowd Demo: Demonstrates local planning an steering using
the crowd manager.

NavmeshQuery Feature Explorer: Lets you play around with
the most of the features of the NavmeshQuery class, often
in ways that you shouldn't.  (So you can see what happens.)

PathCorridor Feature Explorer:  Lets you play around the
the main features of the PathCorridor class, often
in ways that you shouldn't.  (So you can see what happens.)

Miscellany <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

Kaspersky Internet Security may report a PDM.Keylogger 
security warning when Unity applications are run.

http://forum.unity3d.com/threads/36180-PDM.Keylogger-problem

