﻿Demonstates navigation mesh query features

Most classes in this directory demonstrate a single query feature.

The QueryExplorerSim class is the simulation manager.