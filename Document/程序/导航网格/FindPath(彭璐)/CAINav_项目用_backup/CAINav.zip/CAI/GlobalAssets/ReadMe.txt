This directory contains 'singleton' assets. (One per project.)  Various 
editors will use the assets in this directory, automatically creating them
if they don't exist.
