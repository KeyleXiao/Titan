This directory contains the documentation source and build
artifacts.

Sandcastle is used for the documentation build.

The following tools are required:

Sandcastle: http://sandcastle.codeplex.com/
Sandcastle Help File Builder: http://shfb.codeplex.com/

Sandcastle Styles Patch

http://sandcastlestyles.codeplex.com/ - Home Page
http://sandcastlestyles.codeplex.com/releases/view/47767 - Patch Used
