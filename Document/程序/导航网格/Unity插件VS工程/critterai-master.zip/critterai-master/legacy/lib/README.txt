This directory contains shared project libraries.

Compiled project libraries are not normally stored in
the repository. An exception is made when a library is
meant to be shared between projects. In such cases the
compiled library is placed here so that it is available for
dependant project builds and packaging.

(The use of this directory is depreciated.  New projects usually include 
a direct reference to the shared library source.)
