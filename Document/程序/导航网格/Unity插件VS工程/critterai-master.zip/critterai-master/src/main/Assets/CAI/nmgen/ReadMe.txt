The NMGen source is located in the editor directory
since it is normally only used in the Unity Editor.  
This layout prevents code bloat in the Project build.

Just move the source to this directory if NMGen is 
required at runtime.

