Add the following plugins to this directory if you are using it as the basis for
a Unity project:

cai-nav-rcn.dll
cai-nmgen-rcn.dll
