The source code in the 'Assets' directory structure is in the same 
layout it should be if deployed directly to a Unity project.
(I.e. The 'Assets/CAI' directory can be dragged and dropped into
a Unity project.)  The porject documentation contains some important
notes when using a source distribution.
